import java.io.IOException;
import javafx.fxml.FXMLLoader;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import controller.LoginController;
import javafx.stage.Stage;
import model.Model;

public class Main extends Application {
    private Model model;

    @Override
    public void init() {
        model = new Model();
    }

    @Override
    public void start(Stage primaryStage) {
        try {
            model.setup();
            model.setLoginStage(primaryStage);
            openLoginScreen(primaryStage);
        } catch (SQLException | RuntimeException e) {
            showErrorScreen(primaryStage, "Initialization Error: " + e.getMessage());
        }
    }
    
    private void openLoginScreen(Stage primaryStage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/LoginView.fxml"));
            LoginController loginController = new LoginController(primaryStage, model);
            loader.setController(loginController);
            StackPane root = loader.load();
            
            Scene scene = new Scene(root, 500, 300);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Login");
            primaryStage.show();
        } catch (IOException e) {
            showErrorScreen(primaryStage, "Failed to load login screen: " + e.getMessage());
        }
    }
    
    private void showErrorScreen(Stage stage, String message) {
        StackPane root = new StackPane(new Label(message));
        Scene scene = new Scene(root, 600, 400);
        stage.setScene(scene);
        stage.setTitle("Error");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}