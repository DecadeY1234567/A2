package dao;

import java.sql.SQLException;
import model.User;

public interface UserDao {
    void setup() throws SQLException;
    User getUser(String username) throws SQLException;
    User createUser(String username, String password, String preferredName) throws SQLException;
    boolean updatePassword(String username, String newPassword) throws SQLException;
}