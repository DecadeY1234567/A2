package dao;

import java.sql.SQLException;
import java.util.List;
import model.Event;

public interface EventDao {
    void setup() throws SQLException;
    List<Event> getAllEvents() throws SQLException;
    List<Event> getActiveEvents() throws SQLException;
    boolean addEvent(Event event) throws SQLException;
    boolean updateEvent(Event event) throws SQLException;
    boolean deleteEvent(int eventId) throws SQLException;
    boolean setEventActive(int eventId, boolean active) throws SQLException;
    boolean updateTickets(int eventId, int quantity) throws SQLException;
}