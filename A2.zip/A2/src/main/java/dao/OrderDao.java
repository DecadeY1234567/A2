package dao;

import java.sql.SQLException;
import java.util.List;
import model.Order;

public interface OrderDao {
    void setup() throws SQLException;
    int createOrder(int userId, double totalPrice) throws SQLException;
    boolean addOrderItem(int orderId, int eventId, int quantity) throws SQLException;
    List<Order> getOrdersByUser(int userId) throws SQLException;
    List<Order> getAllOrders() throws SQLException;
}