package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Event;

public class EventDaoImpl implements EventDao {
    private final String TABLE_NAME = "events";

    @Override
    public void setup() throws SQLException {
        try (Connection connection = Database.getConnection();
             Statement stmt = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "title TEXT NOT NULL,"
                    + "venue TEXT NOT NULL,"
                    + "day TEXT CHECK(day IN ('Mon','Tue','Wed','Thu','Fri','Sat','Sun')),"
                    + "price REAL NOT NULL,"
                    + "sold_tickets INTEGER DEFAULT 0,"
                    + "total_tickets INTEGER NOT NULL,"
                    + "is_active BOOLEAN DEFAULT 1)";
            stmt.executeUpdate(sql);
            
            // Insert sample data if table is empty
            if (isTableEmpty(connection)) {
                insertSampleData(connection);
            }
        }
    }
    
    private boolean isTableEmpty(Connection conn) throws SQLException {
        String sql = "SELECT COUNT(*) FROM " + TABLE_NAME;
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() && rs.getInt(1) == 0;
        }
    }
    
    private void insertSampleData(Connection conn) throws SQLException {
        String sql = "INSERT INTO " + TABLE_NAME + 
            " (title, venue, day, price, sold_tickets, total_tickets) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            // Jazz Night with Joe events
            insertEvent(pstmt, "Jazz Night with Joe", "Theatre Nova", "Mon", 45.0, 22, 90);
            insertEvent(pstmt, "Jazz Night with Joe", "Theatre Nova", "Tue", 50.0, 30, 90);
            insertEvent(pstmt, "Jazz Night with Joe", "The Media Club", "Fri", 80.0, 70, 100);
            insertEvent(pstmt, "Jazz Night with Joe", "The Media Club", "Sun", 85.0, 60, 100);
            
            // Slow Rock Concert events
            insertEvent(pstmt, "Slow Rock Concert", "Kaleide Theatre", "Thu", 100.0, 100, 200);
            insertEvent(pstmt, "Slow Rock Concert", "Kaleide Theatre", "Sat", 150.0, 150, 200);
            
            // Mozart Chamber Music events
            insertEvent(pstmt, "Mozart Chamber Music", "Studio 1", "Mon", 35.0, 40, 50);
            insertEvent(pstmt, "Mozart Chamber Music", "Concert Hall", "Sat", 50.0, 200, 300);
            insertEvent(pstmt, "Mozart Chamber Music", "Theatre Riverside", "Thu", 40.0, 90, 90);
        }
    }
    
    private void insertEvent(PreparedStatement pstmt, String title, String venue, 
                            String day, double price, int sold, int total) throws SQLException {
        pstmt.setString(1, title);
        pstmt.setString(2, venue);
        pstmt.setString(3, day);
        pstmt.setDouble(4, price);
        pstmt.setInt(5, sold);
        pstmt.setInt(6, total);
        pstmt.executeUpdate();
    }

    @Override
    public List<Event> getAllEvents() throws SQLException {
        List<Event> events = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE_NAME;
        
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                events.add(mapRowToEvent(rs));
            }
        }
        return events;
    }
    
    @Override
    public List<Event> getActiveEvents() throws SQLException {
        List<Event> events = new ArrayList<>();
        String sql = "SELECT * FROM " + TABLE_NAME + " WHERE is_active = 1";
        
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                events.add(mapRowToEvent(rs));
            }
        }
        return events;
    }
    
    private Event mapRowToEvent(ResultSet rs) throws SQLException {
        Event event = new Event();
        event.setId(rs.getInt("id"));
        event.setTitle(rs.getString("title"));
        event.setVenue(rs.getString("venue"));
        event.setDay(rs.getString("day"));
        event.setPrice(rs.getDouble("price"));
        event.setSoldTickets(rs.getInt("sold_tickets"));
        event.setTotalTickets(rs.getInt("total_tickets"));
        event.setActive(rs.getBoolean("is_active"));
        return event;
    }

    @Override
    public boolean addEvent(Event event) throws SQLException {
        String sql = "INSERT INTO " + TABLE_NAME + 
            " (title, venue, day, price, sold_tickets, total_tickets) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, event.getTitle());
            pstmt.setString(2, event.getVenue());
            pstmt.setString(3, event.getDay());
            pstmt.setDouble(4, event.getPrice());
            pstmt.setInt(5, event.getSoldTickets());
            pstmt.setInt(6, event.getTotalTickets());
            
            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean updateEvent(Event event) throws SQLException {
        String sql = "UPDATE " + TABLE_NAME + " SET title = ?, venue = ?, day = ?, price = ?, "
                   + "sold_tickets = ?, total_tickets = ? WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, event.getTitle());
            pstmt.setString(2, event.getVenue());
            pstmt.setString(3, event.getDay());
            pstmt.setDouble(4, event.getPrice());
            pstmt.setInt(5, event.getSoldTickets());
            pstmt.setInt(6, event.getTotalTickets());
            pstmt.setInt(7, event.getId());
            
            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean deleteEvent(int eventId) throws SQLException {
        String sql = "DELETE FROM " + TABLE_NAME + " WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, eventId);
            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean setEventActive(int eventId, boolean active) throws SQLException {
        String sql = "UPDATE " + TABLE_NAME + " SET is_active = ? WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, active);
            pstmt.setInt(2, eventId);
            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public boolean updateTickets(int eventId, int quantity) throws SQLException {
        String sql = "UPDATE " + TABLE_NAME + " SET sold_tickets = sold_tickets + ? WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, eventId);
            return pstmt.executeUpdate() > 0;
        }
    }
}