package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Order;
import model.OrderItem;

public class OrderDaoImpl implements OrderDao {
    private final String ORDER_TABLE = "orders";
    private final String ORDER_ITEM_TABLE = "order_items";

    @Override
    public void setup() throws SQLException {
        try (Connection connection = Database.getConnection();
             Statement stmt = connection.createStatement()) {
            // Create orders table
            String orderSql = "CREATE TABLE IF NOT EXISTS " + ORDER_TABLE + " ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "user_id INTEGER NOT NULL,"
                    + "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,"
                    + "total_price REAL NOT NULL)";
            stmt.executeUpdate(orderSql);
            
            // Create order items table
            String itemSql = "CREATE TABLE IF NOT EXISTS " + ORDER_ITEM_TABLE + " ("
                    + "order_id INTEGER NOT NULL,"
                    + "event_id INTEGER NOT NULL,"
                    + "quantity INTEGER NOT NULL,"
                    + "PRIMARY KEY (order_id, event_id))";
            stmt.executeUpdate(itemSql);
        }
    }

    @Override
    public int createOrder(int userId, double totalPrice) throws SQLException {
        String sql = "INSERT INTO " + ORDER_TABLE + " (user_id, total_price) VALUES (?, ?)";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, userId);
            pstmt.setDouble(2, totalPrice);
            pstmt.executeUpdate();
            
            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
            return -1;
        }
    }

    @Override
    public boolean addOrderItem(int orderId, int eventId, int quantity) throws SQLException {
        String sql = "INSERT INTO " + ORDER_ITEM_TABLE + " VALUES (?, ?, ?)";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, orderId);
            pstmt.setInt(2, eventId);
            pstmt.setInt(3, quantity);
            return pstmt.executeUpdate() > 0;
        }
    }

    @Override
    public List<Order> getOrdersByUser(int userId) throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM " + ORDER_TABLE + " WHERE user_id = ? ORDER BY timestamp DESC";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int orderId = rs.getInt("id");
                    LocalDateTime timestamp = rs.getTimestamp("timestamp").toLocalDateTime();
                    double totalPrice = rs.getDouble("total_price");
                    List<OrderItem> items = getOrderItems(orderId, conn);
                    orders.add(new Order(orderId, userId, timestamp, totalPrice, items));
                }
            }
        }
        return orders;
    }

    @Override
    public List<Order> getAllOrders() throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM " + ORDER_TABLE + " ORDER BY timestamp DESC";
        
        try (Connection conn = Database.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                int orderId = rs.getInt("id");
                int userId = rs.getInt("user_id");
                LocalDateTime timestamp = rs.getTimestamp("timestamp").toLocalDateTime();
                double totalPrice = rs.getDouble("total_price");
                List<OrderItem> items = getOrderItems(orderId, conn);
                orders.add(new Order(orderId, userId, timestamp, totalPrice, items));
            }
        }
        return orders;
    }
    
    private List<OrderItem> getOrderItems(int orderId, Connection conn) throws SQLException {
        List<OrderItem> items = new ArrayList<>();
        String sql = "SELECT oi.*, e.title, e.venue, e.day, e.price " +
                     "FROM " + ORDER_ITEM_TABLE + " oi " +
                     "JOIN events e ON oi.event_id = e.id " +
                     "WHERE order_id = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, orderId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Event event = new Event();
                    event.setId(rs.getInt("event_id"));
                    event.setTitle(rs.getString("title"));
                    event.setVenue(rs.getString("venue"));
                    event.setDay(rs.getString("day"));
                    event.setPrice(rs.getDouble("price"));
                    
                    items.add(new OrderItem(event, rs.getInt("quantity")));
                }
            }
        }
        return items;
    }
}