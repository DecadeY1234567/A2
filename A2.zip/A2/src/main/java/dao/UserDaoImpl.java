package dao;

import java.sql.*;
import model.User;
import util.PasswordUtil;

public class UserDaoImpl implements UserDao {
    private final String TABLE_NAME = "users";

    @Override
    public void setup() throws SQLException {
        try (Connection connection = Database.getConnection();
             Statement stmt = connection.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "username TEXT UNIQUE NOT NULL,"
                    + "password TEXT NOT NULL,"
                    + "preferred_name TEXT NOT NULL,"
                    + "is_admin BOOLEAN DEFAULT 0)";
            stmt.executeUpdate(sql);
            
            // Create admin user if not exists
            String adminSql = "INSERT OR IGNORE INTO " + TABLE_NAME + 
                " (username, password, preferred_name, is_admin) VALUES (?, ?, ?, 1)";
            try (PreparedStatement pstmt = connection.prepareStatement(adminSql)) {
                pstmt.setString(1, "admin");
                pstmt.setString(2, PasswordUtil.encrypt("Admin321"));
                pstmt.setString(3, "Administrator");
                pstmt.executeUpdate();
            }
        }
    }

    @Override
    public User getUser(String username) throws SQLException {
        String sql = "SELECT * FROM " + TABLE_NAME + " WHERE username = ?";
        try (Connection connection = Database.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setPreferredName(rs.getString("preferred_name"));
                    user.setAdmin(rs.getBoolean("is_admin"));
                    return user;
                }
                return null;
            }
        }
    }

    @Override
    public User createUser(String username, String password, String preferredName) throws SQLException {
        String sql = "INSERT INTO " + TABLE_NAME + " (username, password, preferred_name) VALUES (?, ?, ?)";
        try (Connection connection = Database.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, PasswordUtil.encrypt(password));
            stmt.setString(3, preferredName);
            
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                return new User(username, password, preferredName, false);
            }
            return null;
        }
    }

    @Override
    public boolean updatePassword(String username, String newPassword) throws SQLException {
        String sql = "UPDATE " + TABLE_NAME + " SET password = ? WHERE username = ?";
        try (Connection connection = Database.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, PasswordUtil.encrypt(newPassword));
            stmt.setString(2, username);
            return stmt.executeUpdate() > 0;
        }
    }
}