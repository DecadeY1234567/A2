package model;

import java.time.LocalDateTime;
import java.util.List;

public class Order {
    private int id;
    private int userId;
    private LocalDateTime timestamp;
    private double totalPrice;
    private List<OrderItem> items;
    
    public Order(int id, int userId, LocalDateTime timestamp, double totalPrice, List<OrderItem> items) {
        this.id = id;
        this.userId = userId;
        this.timestamp = timestamp;
        this.totalPrice = totalPrice;
        this.items = items;
    }
    
    // Getters
    public int getId() { return id; }
    public int getUserId() { return userId; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public double getTotalPrice() { return totalPrice; }
    public List<OrderItem> getItems() { return items; }
    
    // Formatted string for display
    public String getFormattedTimestamp() {
        return timestamp.toString().replace("T", " ");
    }
    
    public String getEventDetails() {
        StringBuilder sb = new StringBuilder();
        for (OrderItem item : items) {
            sb.append(item.getEvent().getTitle())
              .append(" (").append(item.getQuantity()).append("), ");
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - 2) : "";
    }
}