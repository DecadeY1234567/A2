package model;

public class OrderItem {
    private Event event;
    private int quantity;
    
    public OrderItem(Event event, int quantity) {
        this.event = event;
        this.quantity = quantity;
    }
    
    // Getters
    public Event getEvent() { return event; }
    public int getQuantity() { return quantity; }
}