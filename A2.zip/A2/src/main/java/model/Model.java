package model;

import java.sql.SQLException;
import javafx.stage.Stage;

import dao.EventDao;
import dao.EventDaoImpl;
import dao.OrderDao;
import dao.OrderDaoImpl;
import dao.UserDao;
import dao.UserDaoImpl;
import service.CartManager;

public class Model {
    private UserDao userDao;
    private EventDao eventDao;
    private OrderDao orderDao;
    private User currentUser;
    private CartManager cartManager;
    private Stage loginStage;

    public Model() {
        userDao = new UserDaoImpl();
        eventDao = new EventDaoImpl();
        orderDao = new OrderDaoImpl();
        cartManager = new CartManager();
    }
    
    public void setup() throws SQLException {
        userDao.setup();
        eventDao.setup();
        orderDao.setup();
    }
    
    // Getters
    public UserDao getUserDao() { return userDao; }
    public EventDao getEventDao() { return eventDao; }
    public OrderDao getOrderDao() { return orderDao; }
    public User getCurrentUser() { return currentUser; }
    public CartManager getCartManager() { return cartManager; }
    public Stage getLoginStage() { return loginStage; }
    
    // Setters
    public void setCurrentUser(User user) { this.currentUser = user; }
    public void setCartManager(CartManager cartManager) { this.cartManager = cartManager; }
    public void setLoginStage(Stage loginStage) { this.loginStage = loginStage; }
}