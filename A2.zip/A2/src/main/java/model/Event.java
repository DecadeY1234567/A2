package model;

import javafx.beans.property.*;

public class Event {
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty title = new SimpleStringProperty();
    private final StringProperty venue = new SimpleStringProperty();
    private final StringProperty day = new SimpleStringProperty();
    private final DoubleProperty price = new SimpleDoubleProperty();
    private final IntegerProperty soldTickets = new SimpleIntegerProperty();
    private final IntegerProperty totalTickets = new SimpleIntegerProperty();
    private final BooleanProperty active = new SimpleBooleanProperty(true);
    
    public Event() {}
    
    public Event(int id, String title, String venue, String day, 
                 double price, int soldTickets, int totalTickets) {
        setId(id);
        setTitle(title);
        setVenue(venue);
        setDay(day);
        setPrice(price);
        setSoldTickets(soldTickets);
        setTotalTickets(totalTickets);
    }
    
    // Property getters
    public IntegerProperty idProperty() { return id; }
    public StringProperty titleProperty() { return title; }
    public StringProperty venueProperty() { return venue; }
    public StringProperty dayProperty() { return day; }
    public DoubleProperty priceProperty() { return price; }
    public IntegerProperty soldTicketsProperty() { return soldTickets; }
    public IntegerProperty totalTicketsProperty() { return totalTickets; }
    public IntegerProperty availableProperty() { 
        return new SimpleIntegerProperty(totalTickets.get() - soldTickets.get());
    }
    public BooleanProperty activeProperty() { return active; }
    
    // Standard getters and setters
    public int getId() { return id.get(); }
    public void setId(int id) { this.id.set(id); }
    public String getTitle() { return title.get(); }
    public void setTitle(String title) { this.title.set(title); }
    public String getVenue() { return venue.get(); }
    public void setVenue(String venue) { this.venue.set(venue); }
    public String getDay() { return day.get(); }
    public void setDay(String day) { this.day.set(day); }
    public double getPrice() { return price.get(); }
    public void setPrice(double price) { this.price.set(price); }
    public int getSoldTickets() { return soldTickets.get(); }
    public void setSoldTickets(int soldTickets) { this.soldTickets.set(soldTickets); }
    public int getTotalTickets() { return totalTickets.get(); }
    public void setTotalTickets(int totalTickets) { this.totalTickets.set(totalTickets); }
    public boolean isActive() { return active.get(); }
    public void setActive(boolean active) { this.active.set(active); }
}