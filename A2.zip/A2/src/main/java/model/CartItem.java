package model;

import javafx.beans.property.*;

public class CartItem {
    private final ObjectProperty<Event> event = new SimpleObjectProperty<>();
    private final IntegerProperty quantity = new SimpleIntegerProperty();
    
    public CartItem(Event event, int quantity) {
        setEvent(event);
        setQuantity(quantity);
    }
    
    // Property getters
    public ObjectProperty<Event> eventProperty() { return event; }
    public IntegerProperty quantityProperty() { return quantity; }
    public DoubleProperty totalPriceProperty() { 
        return new SimpleDoubleProperty(getEvent().getPrice() * getQuantity()); 
    }
    
    // Standard getters and setters
    public Event getEvent() { return event.get(); }
    public void setEvent(Event event) { this.event.set(event); }
    public int getQuantity() { return quantity.get(); }
    public void setQuantity(int quantity) { this.quantity.set(quantity); }
    public double getTotalPrice() { return getEvent().getPrice() * getQuantity(); }
}