package service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import dao.EventDao;
import dao.EventDaoImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.CartItem;
import model.Event;

public class CartManager {
    private final ObservableList<CartItem> cartItems = FXCollections.observableArrayList();
    private final EventDao eventDao = new EventDaoImpl();
    
    public ObservableList<CartItem> getCartItems() {
        return cartItems;
    }
    
    public double getTotalPrice() {
        return cartItems.stream()
                .mapToDouble(CartItem::getTotalPrice)
                .sum();
    }
    
    public boolean addToCart(Event event, int quantity) throws SQLException {
        // Check availability
        int available = event.getTotalTickets() - event.getSoldTickets();
        if (quantity > available) {
            return false;
        }
        
        // Check if event already in cart
        for (CartItem item : cartItems) {
            if (item.getEvent().getId() == event.getId()) {
                int newQuantity = item.getQuantity() + quantity;
                if (newQuantity > available) {
                    return false;
                }
                item.setQuantity(newQuantity);
                return true;
            }
        }
        
        // Add new item to cart
        cartItems.add(new CartItem(event, quantity));
        return true;
    }
    
    public void removeFromCart(CartItem item) {
        cartItems.remove(item);
    }
    
    public void clearCart() {
        cartItems.clear();
    }
    
    public boolean validateEventDates() {
        // For simplicity, assume all events are valid
        // Real implementation would check each event's day against current date
        return true;
    }
}