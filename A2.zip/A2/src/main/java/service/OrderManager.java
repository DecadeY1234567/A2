package service;

public class OrderManager {

}
package service;

import java.sql.SQLException;
import dao.EventDao;
import dao.EventDaoImpl;
import dao.OrderDao;
import dao.OrderDaoImpl;
import model.CartItem;
import model.User;

public class OrderManager {
    private final OrderDao orderDao = new OrderDaoImpl();
    private final EventDao eventDao = new EventDaoImpl();
    
    public boolean placeOrder(User user, List<CartItem> cartItems) throws SQLException {
        // Calculate total price
        double totalPrice = cartItems.stream()
                .mapToDouble(CartItem::getTotalPrice)
                .sum();
        
        // Create order
        int orderId = orderDao.createOrder(user.getId(), totalPrice);
        if (orderId == -1) {
            return false;
        }
        
        // Add order items
        for (CartItem item : cartItems) {
            if (!orderDao.addOrderItem(orderId, item.getEvent().getId(), item.getQuantity())) {
                return false;
            }
            
            // Update ticket count
            if (!eventDao.updateTickets(item.getEvent().getId(), item.getQuantity())) {
                return false;
            }
        }
        
        return true;
    }
}