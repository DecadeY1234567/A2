package util;

import java.time.LocalDate;

public class Validator {
    public static boolean isValidConfirmationCode(String code) {
        return code != null && code.matches("\\d{6}");
    }
    
    public static boolean isValidEventDay(String eventDay, LocalDate currentDate) {
        int currentDayValue = currentDate.getDayOfWeek().getValue();
        int eventDayValue = switch(eventDay) {
            case "Mon" -> 1;
            case "Tue" -> 2;
            case "Wed" -> 3;
            case "Thu" -> 4;
            case "Fri" -> 5;
            case "Sat" -> 6;
            case "Sun" -> 7;
            default -> 0;
        };
        return eventDayValue >= currentDayValue;
    }
}