package util;

public class PasswordUtil {
    // Caesar cipher encryption (shift by 3)
    public static String encrypt(String input) {
        if (input == null) return null;
        
        StringBuilder sb = new StringBuilder();
        for (char c : input.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isLowerCase(c) ? 'a' : 'A';
                c = (char)(((c - base + 3) % 26) + base);
            } else if (Character.isDigit(c)) {
                c = (char)(((c - '0' + 3) % 10) + '0');
            }
            sb.append(c);
        }
        return sb.toString();
    }
    
    public static boolean verify(String input, String encrypted) {
        return encrypt(input).equals(encrypted);
    }
}