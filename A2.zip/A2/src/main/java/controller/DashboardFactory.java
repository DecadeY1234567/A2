package controller;

import javafx.scene.layout.Pane;
import model.User;

public interface DashboardFactory {
    Pane createDashboard(User user);
}

// 用户仪表盘工厂
public class UserDashboardFactory implements DashboardFactory {
    @Override
    public Pane createDashboard(User user) {
        // 返回用户特定的UI组件
        return new UserHomeView(user);
    }
}

// 管理员仪表盘工厂
public class AdminDashboardFactory implements DashboardFactory {
    @Override
    public Pane createDashboard(User user) {
        // 返回管理员特定的UI组件
        return new AdminHomeView(user);
    }
}

// 在登录控制器中使用
public class LoginController {
    // ...
    private Pane createDashboard(User user) {
        DashboardFactory factory = user.isAdmin() ? 
            new AdminDashboardFactory() : new UserDashboardFactory();
        return factory.createDashboard(user);
    }
}