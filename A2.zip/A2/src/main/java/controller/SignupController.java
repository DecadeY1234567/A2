package controller;

import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Model;
import model.User;

public class SignupController {
    @FXML private TextField usernameField;
    @FXML private TextField passwordField;
    @FXML private TextField preferredNameField;
    @FXML private Button createButton;
    @FXML private Button cancelButton;
    @FXML private Label statusLabel;
    
    private Stage stage;
    private Stage parentStage;
    private Model model;
    
    public SignupController(Stage parentStage, Model model) {
        this.stage = new Stage();
        this.parentStage = parentStage;
        this.model = model;
    }

    @FXML
    public void initialize() {
        createButton.setOnAction(event -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            String preferredName = preferredNameField.getText();
            
            if (username.isEmpty() || password.isEmpty() || preferredName.isEmpty()) {
                showStatus("All fields are required", Color.RED);
                return;
            }
            
            try {
                User user = model.getUserDao().createUser(username, password, preferredName);
                if (user != null) {
                    showStatus("Account created successfully! Please login.", Color.GREEN);
                    clearFields();
                } else {
                    showStatus("Failed to create account", Color.RED);
                }
            } catch (SQLException e) {
                showStatus("Error: " + e.getMessage(), Color.RED);
            }
        });

        cancelButton.setOnAction(event -> {
            stage.close();
            parentStage.show();
        });
    }
    
    private void showStatus(String text, Color color) {
        statusLabel.setText(text);
        statusLabel.setTextFill(color);
    }
    
    private void clearFields() {
        usernameField.clear();
        passwordField.clear();
        preferredNameField.clear();
    }
    
    public void showStage(Pane root) {
        Scene scene = new Scene(root, 500, 300);
        stage.setScene(scene);
        stage.setTitle("Sign Up");
        stage.show();
    }
}