package controller;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Model;
import model.CartItem;
import service.CartManager;

public class CartController {
    @FXML private TableView<CartItem> cartTable;
    @FXML private TableColumn<CartItem, String> eventColumn;
    @FXML private TableColumn<CartItem, Integer> quantityColumn;
    @FXML private TableColumn<CartItem, Double> priceColumn;
    @FXML private Label totalLabel;
    @FXML private Button checkoutButton;
    @FXML private Button removeButton;
    @FXML private Button backButton;
    
    private Model model;
    private Stage stage;
    private CartManager cartManager;

    public CartController(Stage stage, Model model) {
        this.stage = stage;
        this.model = model;
        this.cartManager = model.getCartManager();
    }
    
    @FXML
    public void initialize() {
        // Initialize table columns
        eventColumn.setCellValueFactory(cellData -> cellData.getValue().getEvent().titleProperty());
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
        
        // Set table data
        cartTable.setItems(cartManager.getCartItems());
        
        // Update total
        updateTotal();
        
        // Set button actions
        checkoutButton.setOnAction(event -> openCheckoutScreen());
        removeButton.setOnAction(event -> removeItem());
        backButton.setOnAction(event -> stage.close());
        
        // Listen for cart changes
        cartManager.getCartItems().addListener((obs, oldVal, newVal) -> updateTotal());
    }
    
    private void updateTotal() {
        double total = cartManager.getTotalPrice();
        totalLabel.setText(String.format("Total: $%.2f", total));
    }
    
    private void removeItem() {
        CartItem selectedItem = cartTable.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            cartManager.removeFromCart(selectedItem);
        }
    }
    
    private void openCheckoutScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/CheckoutView.fxml"));
            CheckoutController checkoutController = new CheckoutController(stage, model);
            loader.setController(checkoutController);
            Pane root = loader.load();
            checkoutController.showStage(root);
        } catch (IOException e) {
            showAlert("Error", "Failed to open checkout: " + e.getMessage());
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void showStage(Pane root) {
        Scene scene = new Scene(root, 600, 400);
        stage.setScene(scene);
        stage.setTitle("Shopping Cart");
        stage.show();
    }
}