package controller;

import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Model;
import service.CartManager;
import service.OrderManager;
import util.Validator;

public class CheckoutController {
    @FXML private Label totalLabel;
    @FXML private TextField confirmationCodeField;
    @FXML private Button confirmButton;
    @FXML private Button cancelButton;
    
    private Model model;
    private Stage stage;
    private CartManager cartManager;

    public CheckoutController(Stage stage, Model model) {
        this.stage = stage;
        this.model = model;
        this.cartManager = model.getCartManager();
    }
    
    @FXML
    public void initialize() {
        totalLabel.setText(String.format("Total: $%.2f", cartManager.getTotalPrice()));
        
        confirmButton.setOnAction(event -> processCheckout());
        cancelButton.setOnAction(event -> stage.close());
    }
    
    private void processCheckout() {
        String confirmationCode = confirmationCodeField.getText();
        
        // Validate confirmation code
        if (!Validator.isValidConfirmationCode(confirmationCode)) {
            showAlert("Invalid Code", "Confirmation code must be 6 digits");
            return;
        }
        
        // Validate event dates (simplified)
        if (!cartManager.validateEventDates()) {
            showAlert("Date Error", "Cannot book events from past days");
            return;
        }
        
        try {
            OrderManager orderManager = new OrderManager();
            if (orderManager.placeOrder(model.getCurrentUser(), cartManager.getCartItems())) {
                showAlert("Success", "Order placed successfully!");
                cartManager.clearCart();
                stage.close();
            } else {
                showAlert("Error", "Failed to place order");
            }
        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void showStage(Pane root) {
        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.setTitle("Checkout");
        stage.show();
    }
}