package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Model;
import model.Event;
import service.CartManager;

public class HomeController {
    @FXML private Label welcomeLabel;
    @FXML private TableView<Event> eventTable;
    @FXML private TableColumn<Event, String> titleColumn;
    @FXML private TableColumn<Event, String> venueColumn;
    @FXML private TableColumn<Event, String> dayColumn;
    @FXML private TableColumn<Event, Double> priceColumn;
    @FXML private TableColumn<Event, Integer> availableColumn;
    @FXML private Spinner<Integer> quantitySpinner;
    @FXML private Button addToCartButton;
    @FXML private Button viewCartButton;
    @FXML private Button viewOrdersButton;
    @FXML private Button logoutButton;
    
    private Model model;
    private Stage stage;
    private CartManager cartManager;
    private ObservableList<Event> events;

    public HomeController(Stage stage, Model model) {
        this.stage = stage;
        this.model = model;
        this.cartManager = new CartManager();
    }
    
    @FXML
    public void initialize() {
        // Initialize cart manager
        model.setCartManager(cartManager);
        
        // Set welcome message
        welcomeLabel.setText("Welcome, " + model.getCurrentUser().getPreferredName());
        
        // Initialize event table columns
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        venueColumn.setCellValueFactory(new PropertyValueFactory<>("venue"));
        dayColumn.setCellValueFactory(new PropertyValueFactory<>("day"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        availableColumn.setCellValueFactory(new PropertyValueFactory<>("available"));
        
        // Load events
        loadEvents();
        
        // Initialize quantity spinner
        quantitySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 1));
        
        // Set button actions
        addToCartButton.setOnAction(event -> addToCart());
        viewCartButton.setOnAction(event -> openCartScreen());
        viewOrdersButton.setOnAction(event -> openOrdersScreen());
        logoutButton.setOnAction(event -> logout());
    }
    
    private void loadEvents() {
        try {
            List<Event> eventList = model.getEventDao().getActiveEvents();
            events = FXCollections.observableArrayList(eventList);
            eventTable.setItems(events);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load events: " + e.getMessage());
        }
    }
    
    private void addToCart() {
        Event selectedEvent = eventTable.getSelectionModel().getSelectedItem();
        if (selectedEvent == null) {
            showAlert("No Selection", "Please select an event first");
            return;
        }
        
        int quantity = quantitySpinner.getValue();
        try {
            if (cartManager.addToCart(selectedEvent, quantity)) {
                showAlert("Success", quantity + " tickets added to cart");
            } else {
                showAlert("Error", "Not enough tickets available");
            }
        } catch (SQLException e) {
            showAlert("Database Error", e.getMessage());
        }
    }
    
    private void openCartScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/CartView.fxml"));
            CartController cartController = new CartController(stage, model);
            loader.setController(cartController);
            Pane root = loader.load();
            cartController.showStage(root);
        } catch (IOException e) {
            showAlert("Error", "Failed to open cart: " + e.getMessage());
        }
    }
    
    private void openOrdersScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/OrdersView.fxml"));
            OrdersController ordersController = new OrdersController(stage, model);
            loader.setController(ordersController);
            Pane root = loader.load();
            ordersController.showStage(root);
        } catch (IOException e) {
            showAlert("Error", "Failed to open orders: " + e.getMessage());
        }
    }
    
    private void logout() {
        cartManager.clearCart();
        stage.close();
        model.getLoginStage().show();
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void showStage(Pane root) {
        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.setTitle("Event Booking System");
        stage.show();
    }
}