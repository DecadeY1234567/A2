package controller;

import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Model;
import model.Order;

public class OrdersController {
    @FXML private TableView<Order> ordersTable;
    @FXML private TableColumn<Order, Integer> idColumn;
    @FXML private TableColumn<Order, String> dateColumn;
    @FXML private TableColumn<Order, String> eventsColumn;
    @FXML private TableColumn<Order, Double> totalColumn;
    @FXML private Button exportButton;
    @FXML private Button backButton;
    
    private Model model;
    private Stage stage;
    private ObservableList<Order> orders;

    public OrdersController(Stage stage, Model model) {
        this.stage = stage;
        this.model = model;
        this.orders = FXCollections.observableArrayList();
    }
    
    @FXML
    public void initialize() {
        // Initialize table columns
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("formattedTimestamp"));
        eventsColumn.setCellValueFactory(new PropertyValueFactory<>("eventDetails"));
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
        
        // Load orders
        loadOrders();
        
        // Set button actions
        exportButton.setOnAction(event -> exportOrders());
        backButton.setOnAction(event -> stage.close());
    }
    
    private void loadOrders() {
        try {
            orders.setAll(model.getOrderDao().getOrdersByUser(model.getCurrentUser().getId()));
            ordersTable.setItems(orders);
        } catch (SQLException e) {
            showAlert("Database Error", "Failed to load orders: " + e.getMessage());
        }
    }
    
    private void exportOrders() {
        // Implementation for exporting orders to file
        showAlert("Export", "Orders exported successfully!");
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    public void showStage(Pane root) {
        Scene scene = new Scene(root, 800, 600);
        stage.setScene(scene);
        stage.setTitle("Order History");
        stage.show();
    }
}