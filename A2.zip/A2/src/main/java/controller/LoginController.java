package controller;

import java.io.IOException;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import model.Model;
import model.User;
import util.PasswordUtil;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label messageLabel;
    @FXML private Button loginButton;
    @FXML private Button signupButton;

    private Model model;
    private Stage stage;
    
    public LoginController(Stage stage, Model model) {
        this.stage = stage;
        this.model = model;
    }
    
    @FXML
    public void initialize() {        
        loginButton.setOnAction(event -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            
            if (username.isEmpty() || password.isEmpty()) {
                showMessage("Username and password are required", Color.RED);
                return;
            }
            
            try {
                User user = model.getUserDao().getUser(username);
                if (user != null && PasswordUtil.verify(password, user.getPassword())) {
                    model.setCurrentUser(user);
                    openHomeScreen();
                } else {
                    showMessage("Invalid username or password", Color.RED);
                }
            } catch (SQLException e) {
                showMessage("Database error: " + e.getMessage(), Color.RED);
            }
        });
        
        signupButton.setOnAction(event -> {
            try {
                openSignupScreen();
            } catch (IOException e) {
                showMessage("Failed to open signup: " + e.getMessage(), Color.RED);
            }
        });
    }
    
    private void openHomeScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/HomeView.fxml"));
            HomeController homeController = new HomeController(stage, model);
            loader.setController(homeController);
            Pane root = loader.load();
            
            homeController.showStage(root);
            stage.close();
        } catch (IOException e) {
            showMessage("Failed to open home screen: " + e.getMessage(), Color.RED);
        }
    }
    
    private void openSignupScreen() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/SignupView.fxml"));
        SignupController signupController = new SignupController(stage, model);
        loader.setController(signupController);
        Pane root = loader.load();
        
        signupController.showStage(root);
        stage.hide();
    }
    
    private void showMessage(String text, Color color) {
        messageLabel.setText(text);
        messageLabel.setTextFill(color);
    }
    
    public void showStage(Pane root) {
        Scene scene = new Scene(root, 500, 300);
        stage.setScene(scene);
        stage.setTitle("Login");
        stage.show();
    }
}